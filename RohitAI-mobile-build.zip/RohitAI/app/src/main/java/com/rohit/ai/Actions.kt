package com.rohit.ai
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager

object Actions {
  fun openApp(c: Context, name: String): String {
    val pm = c.packageManager
    val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    val m = l.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return "App $name not found."
    c.startActivity(pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return "Opening ${m.loadLabel(pm)}." }
  fun openUrl(c: Context, u: String): String { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Opened in browser." }
  fun findContact(c: Context, name: String): Pair<String, String>? = try {
    c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
      arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
      "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use {
      if (it.moveToFirst()) it.getString(0) to it.getString(1) else null } } catch (e: SecurityException) { null }
  fun nameForNumber(c: Context, n: String): String? = try {
    c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n)),
      arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
  } catch (e: SecurityException) { null }
  fun call(c: Context, num: String) = try {
    c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Calling."
  } catch (e: SecurityException) { "Call permission not granted." }
  fun sms(c: Context, num: String, body: String) = try {
    val m = c.getSystemService(SmsManager::class.java); m.sendMultipartTextMessage(num, null, m.divideMessage(body), null, null)
    "SMS handed to the system. (Delivery is not confirmed.)"
  } catch (e: Exception) { "SMS failed: ${e.message}" } }
