package com.rohit.ai
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PhoneControlService : AccessibilityService() {
  companion object { var inst: PhoneControlService? = null }
  override fun onServiceConnected() { inst = this }
  override fun onUnbind(i: android.content.Intent?): Boolean { inst = null; return super.onUnbind(i) }
  override fun onDestroy() { inst = null; super.onDestroy() }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  fun act(a: Int) = performGlobalAction(if (a == 1) GLOBAL_ACTION_BACK else GLOBAL_ACTION_HOME)
  fun tap(label: String): Boolean {
    val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(label)?.firstOrNull() ?: return false
    var x: AccessibilityNodeInfo? = n
    while (x != null && !x.isClickable) x = x.parent
    return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false }
  fun scroll(fwd: Boolean): Boolean {
    fun f(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? { if (n == null) return null; if (n.isScrollable) return n
      for (i in 0 until n.childCount) f(n.getChild(i))?.let { return it }; return null }
    return f(rootInActiveWindow)?.performAction(if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false }
  fun screenText(): String { val sb = StringBuilder()
    fun w(n: AccessibilityNodeInfo?) { if (n == null) return; n.text?.let { sb.append(it).append(". ") }; for (i in 0 until n.childCount) w(n.getChild(i)) }
    w(rootInActiveWindow); return sb.toString() } }
