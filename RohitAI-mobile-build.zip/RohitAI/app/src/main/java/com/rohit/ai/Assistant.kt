package com.rohit.ai
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

object Assistant {
  lateinit var app: Context; private var tts: TextToSpeech? = null
  val status = mutableStateOf("Idle"); val log = mutableStateListOf<String>()
  private val history = JSONArray(); private var pending: (() -> Unit)? = null; private var pendingDesc = ""
  const val SYS = "You are ROHIT AI, a friendly voice assistant. Reply in the user's language (Bengali, Hindi or English), short and natural. " +
    "Return ONLY JSON: {\"say\":\"...\",\"action\":{\"type\":\"none|open_app|tap|scroll|back|home|read_screen|call|sms|search\",\"arg\":\"app/button/contact/query\",\"body\":\"sms text\"}}. " +
    "If a command is unclear, ask a clarifying question with type none. Never claim an action succeeded; the app reports results."

  fun init(c: Context) { if (tts != null) return; app = c.applicationContext
    tts = TextToSpeech(app) { tts?.language = Locale("bn", "IN") } }
  private fun prefs() = EncryptedSharedPreferences.create(app, "sec",
    MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
  fun apiKey() = prefs().getString("key", "") ?: ""
  fun saveKey(k: String) = prefs().edit().putString("key", k.trim()).apply()

  fun say(t: String) { log.add("AI: $t"); tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "r") }
  fun stopSpeaking() { tts?.stop() }
  fun setLang(code: String) { tts?.language = Locale(code, if (code == "en") "US" else "IN") }

  fun handle(text: String) { log.add("You: $text")
    val p = pending
    if (p != null) { pending = null
      if (Regex("yes|yeah|ok|haan|ha|হ্যাঁ|হ্যা|হাঁ|हाँ|हां|ठीक", RegexOption.IGNORE_CASE).containsMatchIn(text)) p() else say("Cancelled.")
      return }
    thread { try { val r = ask(text); say(r.optString("say"))
      val a = r.optJSONObject("action") ?: return@thread
      run(a.optString("type"), a.optString("arg"), a.optString("body"))
    } catch (e: Exception) { say("Sorry, I could not reach Gemini: ${e.message}") } } }

  private fun confirm(desc: String, go: () -> Unit) { pending = { go() }; pendingDesc = desc; say("$desc — confirm? Say yes or no.") }

  private fun run(type: String, arg: String, body: String) {
    val a = PhoneControlService.inst
    fun needA11y(f: (PhoneControlService) -> String) = say(if (a == null) "Accessibility service is off. Please enable it in Settings." else f(a))
    when (type) {
      "open_app" -> say(Actions.openApp(app, arg))
      "tap" -> needA11y { if (it.tap(arg)) "Tapped $arg." else "I could not find a button named $arg." }
      "scroll" -> needA11y { if (it.scroll(arg != "up")) "Scrolled." else "Nothing to scroll." }
      "back" -> needA11y { it.act(1); "Went back." }
      "home" -> needA11y { it.act(2); "Went home." }
      "read_screen" -> needA11y { it.screenText().ifBlank { "No readable text." }.take(600) }
      "search" -> say(Actions.openUrl(app, "https://www.google.com/search?q=" + java.net.URLEncoder.encode(arg, "UTF-8")))
      "call" -> { val n = Actions.findContact(app, arg)
        if (n == null) say("I could not find $arg in contacts.") else confirm("Call ${n.first}?") { say(Actions.call(app, n.second)) } }
      "sms" -> { val n = Actions.findContact(app, arg)
        if (n == null) say("I could not find $arg in contacts.") else confirm("Send \"$body\" to ${n.first}?") { say(Actions.sms(app, n.second, body)) } }
    } }

  private fun ask(text: String): JSONObject {
    history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
    val req = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
      .put("contents", history).put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent").openConnection() as HttpURLConnection
    c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
    c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", apiKey())
    c.outputStream.use { it.write(req.toString().toByteArray()) }
    if (c.responseCode !in 200..299) error("HTTP ${c.responseCode} (check API key/network)")
    val out = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
      .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out))))
    while (history.length() > 24) history.remove(0)
    return JSONObject(out) } }
