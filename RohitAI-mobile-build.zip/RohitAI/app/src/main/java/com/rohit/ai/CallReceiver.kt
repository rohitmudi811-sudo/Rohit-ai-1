package com.rohit.ai
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) {
    if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
    val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
    Assistant.init(c)
    val who = Actions.nameForNumber(c, num)
    Assistant.setLang("bn")
    Assistant.say(if (who != null) "Rohit Sir, $who এর কল আসছে।" else "Rohit Sir, একটি অজানা নম্বর থেকে কল আসছে।") } }
