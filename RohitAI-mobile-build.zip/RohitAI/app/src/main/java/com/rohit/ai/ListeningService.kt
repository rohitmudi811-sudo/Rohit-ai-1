package com.rohit.ai
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class ListeningService : Service(), RecognitionListener {
  companion object { var paused = false; var wake = true; var running = false }
  private var sr: SpeechRecognizer? = null; private val h = Handler(Looper.getMainLooper()); private var awakeUntil = 0L
  override fun onBind(i: Intent?): IBinder? = null
  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    when (i?.action) { "STOP" -> { stopSelf(); return START_NOT_STICKY }
      "PAUSE" -> { paused = true; sr?.cancel(); Assistant.status.value = "Paused"; return START_STICKY }
      "RESUME" -> { paused = false; listen(); return START_STICKY } }
    Assistant.init(this)
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("mic", "Listening", NotificationManager.IMPORTANCE_LOW))
    fun pi(a: String) = PendingIntent.getService(this, a.hashCode(), Intent(this, ListeningService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
    val n = Notification.Builder(this, "mic").setContentTitle("ROHIT AI is listening").setContentText("Microphone is ON")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
      .addAction(Notification.Action.Builder(null, "Pause", pi("PAUSE")).build())
      .addAction(Notification.Action.Builder(null, "Resume", pi("RESUME")).build())
      .addAction(Notification.Action.Builder(null, "Stop", pi("STOP")).build()).build()
    startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    running = true; paused = false; listen(); return START_STICKY }
  private fun listen() { if (paused || !running) return
    sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this)
      it.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN").putExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayOf("hi-IN", "en-IN"))) }
    Assistant.status.value = if (wake) "Listening for \"Rohit\"…" else "Listening…" }
  override fun onResults(r: android.os.Bundle?) {
    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
    if (!t.isNullOrBlank()) { val now = System.currentTimeMillis()
      val hit = Regex("rohit|রোহিত|रोहित", RegexOption.IGNORE_CASE)
      if (!wake || now < awakeUntil || hit.containsMatchIn(t)) { awakeUntil = now + 20000
        val cmd = hit.replace(t, "").trim(); if (cmd.isNotBlank()) Assistant.handle(cmd) else Assistant.say("জি, বলুন।") } }
    h.postDelayed({ listen() }, 300) }
  override fun onError(e: Int) { h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400) }
  override fun onDestroy() { running = false; sr?.destroy(); h.removeCallbacksAndMessages(null); Assistant.status.value = "Stopped"; super.onDestroy() }
  override fun onReadyForSpeech(p: android.os.Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
  override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(p: android.os.Bundle?) {}
  override fun onEvent(t: Int, p: android.os.Bundle?) {} }
