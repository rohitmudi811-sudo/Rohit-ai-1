package com.rohit.ai
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) { super.onCreate(s); Assistant.init(this)
    setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen() } } }
  @Composable fun Screen() {
    var key by remember { mutableStateOf(Assistant.apiKey()) }; var wake by remember { mutableStateOf(true) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.8f, 1.15f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "o")
    Column(Modifier.fillMaxSize().background(Color(0xFF05070F)).statusBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Canvas(Modifier.size(150.dp)) { val r = size.minDimension / 2 * (if (ListeningService.running && !ListeningService.paused) pulse else 0.9f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF7CF4FF), Color(0xFF6A5CFF), Color.Transparent), Offset(size.width / 2, size.height / 2), r), r) }
      Text(Assistant.status.value, color = Color(0xFF7CF4FF))
      Text(if (ListeningService.running) "🎤 Microphone ON" else "Microphone OFF", color = Color.Gray)
      OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ Assistant.saveKey(key) }) { Text("Save key") }
        Button({ perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_CONTACTS,
          Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)) }) { Text("Permissions") } }
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, ListeningService::class.java)) }) { Text("Start") }
        Button({ startService(Intent(this@MainActivity, ListeningService::class.java).setAction("PAUSE")) }) { Text("Pause") }
        Button({ startService(Intent(this@MainActivity, ListeningService::class.java).setAction("RESUME")) }) { Text("Resume") }
        Button({ startService(Intent(this@MainActivity, ListeningService::class.java).setAction("STOP")) }) { Text("Stop") } }
      Row(verticalAlignment = Alignment.CenterVertically) { Text("Wake word \"Rohit\"", color = Color.White); Switch(wake, { wake = it; ListeningService.wake = it }) }
      OutlinedButton({ startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Enable phone control (Accessibility)") }
      Text("Settings → Accessibility → ROHIT AI → turn on. Turn off anytime to stop control.", color = Color.Gray)
      LazyColumn(Modifier.weight(1f).fillMaxWidth()) { items(Assistant.log.toList().reversed()) { Text(it, color = Color.White, modifier = Modifier.padding(2.dp)) } } } } }
