# ROHIT AI (Kotlin + Jetpack Compose)
## Build APK
1. Install Android Studio (Ladybug+). File > Open > this folder; let Gradle sync (it generates the wrapper).
2. Debug APK: Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk. Copy to phone, allow "install unknown apps".
3. Release: Build > Generate Signed Bundle/APK > APK, create a keystore, choose release.
## First run
Save Gemini key (aistudio.google.com) > Permissions > Start (mic notification appears) > say "Rohit, ..." .
Enable Accessibility manually in Settings. Disable battery optimisation for the app (Settings > Apps > Battery > Unrestricted).
## Not implemented / needs more native work
- Floating overlay button (needs SYSTEM_ALERT_WINDOW + overlay service) - not included.
- Reading incoming *notifications* needs NotificationListenerService - not included.
- Waveform & polished voice settings screens - orb only; TTS voice = system voice (install Bengali voice data).
- Web search = opens Google in browser; Gemini grounding/Custom Search API not wired.
- Key is encrypted on-device. For a distributed app, proxy Gemini via your own backend instead of shipping user keys.
- Android 10+ may block or silence background recognition; Google speech beeps/restarts are OS behaviour. Incoming-number
  announcement needs READ_CALL_LOG; Play Store restricts that permission. Untested: no Android SDK in this sandbox.

## Build from an Android phone (GitHub Actions)
1. Create a GitHub repository in your browser and upload the contents of this project (the `RohitAI` folder contents, not the outer folder).
2. Keep `.github/workflows/android.yml` in the repository. On the repository page open Actions, select `Build ROHIT AI APK`, then choose `Run workflow`.
3. Wait for the run to finish. Open the successful run, scroll to Artifacts, and download `ROHIT-AI-debug-apk`.
4. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

This workflow has been added but has NOT been run in this sandbox. The first cloud build may reveal source or dependency errors that need fixing. Do not upload API keys or passwords to a public repository; use a private repository.
